"""
Hotel Las Acacias

Autor: Walter Sanchez

  habitaciones.py   Gonzalo Monge
  clientes.py       Facundo Miranda
  reservas.py       Santiago Robledo
  tarifas.py        Mateo Lestarpe

Este archivo junta los modulos y arma la demo.
seccion() y mostrar_resumen() son de la plantilla.
"""

from collections.abc import Iterator
from contextlib import contextmanager

import rich
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from clientes import Cliente, ClienteVip
from habitaciones import Habitacion
from reservas import Reserva
from tarifas import Tarifa

consola = Console()

# plantilla
SECCIONES = {
    "Habitaciones": "Gonzalo Monge (habitaciones.py)",
    "Clientes": "Facundo Miranda (clientes.py)",
    "Reservas": "Santiago Robledo (reservas.py)",
    "Tarifas": "Mateo Lestarpe (tarifas.py)",
}

PROBADAS = set()
FALLOS = {}
SIN_ESCRIBIR = set()


@contextmanager
def seccion(titulo: str) -> Iterator[None]:
    """Si un modulo falla, lo anota. main corta despues."""
    try:
        yield
    except NotImplementedError as error:
        SIN_ESCRIBIR.add(titulo)
        consola.print(f"[yellow]Te falta escribir:[/yellow] {titulo} — {error}")
    except Exception as error:
        FALLOS[titulo] = f"{type(error).__name__}: {error}"
        consola.print(
            Panel(
                f"[bold]{titulo}[/bold]\n\n"
                f"Tipo: [yellow]{type(error).__name__}[/yellow]\n"
                f"Error: {error}\n\n"
                f"Responsable: [bold cyan]{SECCIONES.get(titulo, 'main.py')}[/bold cyan]",
                title="FALLO",
                border_style="red",
            )
        )
    else:
        PROBADAS.add(titulo)


def mostrar_resumen() -> None:
    """Tabla final con el estado de cada modulo."""
    tabla_resumen = Table(title="Resumen del proyecto")
    tabla_resumen.add_column("Seccion")
    tabla_resumen.add_column("Responsable")
    tabla_resumen.add_column("Estado")

    pendientes = 0
    for titulo, responsable in SECCIONES.items():
        if titulo in FALLOS:
            estado = "[red]fallo[/red]"
            pendientes += 1
        elif titulo in SIN_ESCRIBIR:
            estado = "[yellow]te falta[/yellow]"
            pendientes += 1
        elif titulo in PROBADAS:
            estado = "[green]funciona[/green]"
        else:
            estado = "[yellow]sin probar[/yellow]"
            pendientes += 1
        tabla_resumen.add_row(titulo, responsable, estado)

    consola.print(tabla_resumen)

    if not pendientes:
        consola.print("[green]Las secciones corrieron, sin error.[/green]")
    elif SIN_ESCRIBIR:
        consola.print("[yellow]Falta algo de main.py. Mirá los «te falta».[/yellow]")
    else:
        consola.print(f"[yellow]Faltan {pendientes} de {len(SECCIONES)} secciones.[/yellow]")


def pesos(monto):
    # 45000 queda como $ 45.000
    return f"$ {int(monto):,}".replace(",", ".")


def armar_tabla(titulo, columnas, filas):
    tabla = Table(title=titulo)
    for columna in columnas:
        tabla.add_column(columna)
    for fila in filas:
        tabla.add_row(*fila)
    consola.print(tabla)


def buscar_habitacion(habitaciones, numero):
    for habitacion in habitaciones:
        if habitacion.numero_habitacion == numero:
            return habitacion
    raise ValueError(f"No existe la habitacion {numero}")


def mostrar_reserva(reserva):
    filas = []
    for estadia in reserva.estadias:
        hab = estadia.habitacion
        filas.append([
            str(hab.numero_habitacion), hab.tipo, str(estadia.noches),
            pesos(hab.tarifa.precio_noche), pesos(estadia.subtotal()),
        ])
    armar_tabla(
        f"Reserva #{reserva.numero} - {reserva.cliente.nombre}",
        ["Habitacion", "Tipo", "Noches", "Precio/noche", "Subtotal"],
        filas,
    )
    consola.print(f"Total: {pesos(reserva.total())}")
    consola.print(f"Estado: {reserva.estado}")
    consola.print(f"Cantidad de habitaciones: {reserva.habitaciones_totales()}")
    if reserva.cliente.descuento:
        consola.print(f"Descuento: {reserva.cliente.descuento:.0%}")


def estado_habitacion(habitacion):
    if habitacion.disponible:
        return "libre"
    return "ocupada"


def cortar():
    if FALLOS or SIN_ESCRIBIR:
        mostrar_resumen()
        return True
    return False


def mostrar_tarifas():
    tarifas = [
        Tarifa("simple", 45000),
        Tarifa("doble", 70000),
        Tarifa("triple", 95000),
        Tarifa("cuadruple", 120000),
    ]
    filas = []
    for tarifa in tarifas:
        filas.append([
            tarifa.tipo_habitacion,
            pesos(tarifa.precio_noche),
            pesos(tarifa.calcular_total(3)),
        ])
    armar_tabla("Tarifas por 3 noches", ["Tipo", "Precio/noche", "Total"], filas)
    return tarifas


def mostrar_habitaciones(tarifas):
    numeros = (101, 102, 201, 202)
    habitaciones = []
    for numero, tarifa in zip(numeros, tarifas):
        hab = Habitacion(numero, tarifa.tipo_habitacion)
        hab.tarifa = tarifa
        habitaciones.append(hab)
    filas = []
    for hab in habitaciones:
        filas.append([
            str(hab.numero_habitacion), hab.tipo,
            pesos(hab.tarifa.precio_noche), estado_habitacion(hab),
        ])
    armar_tabla("Habitaciones", ["Numero", "Tipo", "Precio/noche", "Estado"], filas)
    # la 202 no entra en una reserva: solo pruebo ocupar y liberar
    hab_202 = buscar_habitacion(habitaciones, 202)
    consola.print(hab_202.ocupar())
    consola.print(hab_202.liberar())
    return habitaciones


def mostrar_clientes():
    # la habitacion no se carga aca: la pone la reserva
    ana = ClienteVip("Ana Ruiz", "ana@ejemplo.com", descuento=0.10)
    luis = Cliente("Luis Paz", "luis@ejemplo.com")
    marta = Cliente("Marta Solo", "marta@ejemplo.com")
    filas = []
    for cliente in (ana, luis, marta):
        if cliente.tiene_habitacion:
            numero = str(cliente.numero_habitacion)
        else:
            numero = "sin asignar"
        filas.append([
            cliente.nombre, cliente.email, numero, f"{cliente.descuento:.0%}",
        ])
    armar_tabla(
        "Huespedes", ["Nombre", "Email", "Habitacion", "Descuento"], filas,
    )
    return ana, luis


def imprimir_habitaciones(reserva):
    for estadia in reserva.estadias:
        hab = estadia.habitacion
        consola.print(
            f"Habitacion {hab.numero_habitacion}: {estado_habitacion(hab)}"
        )


def confirmar_reserva(reserva):
    reserva.cambiar_estado("Confirmada")
    consola.print(f"{reserva} - {reserva.estado}")
    imprimir_habitaciones(reserva)
    if reserva.cliente.tiene_habitacion:
        numero = reserva.cliente.numero_habitacion
        consola.print(f"Ana queda con la habitacion {numero}")
    else:
        consola.print("Ana queda sin habitacion")


def probar_agregar_estadia(reserva, habitaciones):
    try:
        reserva.agregar_estadia(buscar_habitacion(habitaciones, 202), 1)
    except (RuntimeError, ValueError) as error:
        consola.print(f"No se pudo agregar: {error}")


def cancelar_reserva(reserva):
    reserva.cambiar_estado("Cancelada")
    consola.print(f"{reserva} - {reserva.estado}")
    imprimir_habitaciones(reserva)
    if reserva.cliente.tiene_habitacion:
        numero = reserva.cliente.numero_habitacion
        consola.print(f"Ana sigue con la habitacion {numero}")
    else:
        consola.print("Ana queda sin habitacion")


def reservar_luis(habitaciones, luis):
    reserva = Reserva(cliente=luis)
    reserva.agregar_estadia(buscar_habitacion(habitaciones, 102), 2)
    mostrar_reserva(reserva)


def mostrar_reservas(habitaciones, ana, luis):
    reserva_ana = Reserva(cliente=ana)
    reserva_ana.agregar_estadia(buscar_habitacion(habitaciones, 101), 3)
    reserva_ana.agregar_estadia(buscar_habitacion(habitaciones, 201), 2)
    mostrar_reserva(reserva_ana)
    confirmar_reserva(reserva_ana)
    probar_agregar_estadia(reserva_ana, habitaciones)
    cancelar_reserva(reserva_ana)
    reservar_luis(habitaciones, luis)


def main():
    rich.print("[bold green]Hotel Las Acacias[/bold green]\n")
    tarifas = habitaciones = ana = luis = None
    with seccion("Tarifas"):
        tarifas = mostrar_tarifas()
    if cortar() or tarifas is None:
        return
    with seccion("Habitaciones"):
        habitaciones = mostrar_habitaciones(tarifas)
    if cortar() or habitaciones is None:
        return
    with seccion("Clientes"):
        ana, luis = mostrar_clientes()
    if cortar() or ana is None or luis is None:
        return
    with seccion("Reservas"):
        mostrar_reservas(habitaciones, ana, luis)
    if not cortar():
        mostrar_resumen()


if __name__ == "__main__":
    main()
