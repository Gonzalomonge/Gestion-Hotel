"""
Módulo — Tarifas del hotel.

Autor: Mateo Lestarpe

Contiene la clase Tarifa, que administra el precio
por noche y calcula el costo de una estadía.
"""


class Tarifa:
    """Representa la tarifa de un tipo de habitación."""

    def __init__(self, tipo_habitacion: str, precio_noche: float) -> None:
        if not isinstance(tipo_habitacion, str) or not tipo_habitacion.strip():
            raise ValueError("El tipo de habitación no puede estar vacío.")

        self._tipo_habitacion = tipo_habitacion
        self._precio_noche = 0
        self.precio_noche = precio_noche

    @property
    def tipo_habitacion(self) -> str:
        return self._tipo_habitacion

    @property
    def precio_noche(self) -> float:
        return self._precio_noche

    @precio_noche.setter
    def precio_noche(self, nuevo_precio: float) -> None:
        if not isinstance(nuevo_precio, (int, float)) or isinstance(nuevo_precio, bool):
            raise ValueError("El precio debe ser un número.")

        if nuevo_precio <= 0:
            raise ValueError("El precio por noche debe ser mayor que 0.")

        self._precio_noche = nuevo_precio

    def calcular_total(self, noches: int) -> float:
        if not isinstance(noches, int) or isinstance(noches, bool):
            raise ValueError("La cantidad de noches debe ser un número entero.")

        if noches <= 0:
            raise ValueError("La cantidad de noches debe ser positiva.")

        return self.precio_noche * noches

    def __str__(self) -> str:
        return f"Tarifa de habitación {self.tipo_habitacion}: ${self.precio_noche} por noche"

    def __repr__(self) -> str:
        return f"Tarifa(tipo_habitacion={self.tipo_habitacion!r}, precio_noche={self.precio_noche!r})"


if __name__ == "__main__":
    tarifa = Tarifa("Doble", 50000)

    print(tarifa)
    print(f"Costo por 3 noches: ${tarifa.calcular_total(3)}")

    tarifa.precio_noche = 60000
    print(f"Nueva tarifa: {tarifa}")