"""
Sistema de gestion hotelera.
El módulo habitaciones.py se encarga de gestionar las habitaciones del hotel. Permite crear habitaciones, validar sus datos,
consultar si están disponibles y cambiar su estado mediante los métodos ocupar() y liberar().
Forma parte del sistema y trabaja junto con los demás módulos, especialmente el de reservas.
"""
class Habitacion:
    def __init__(self, numero_habitacion: int, tipo):
        self.numero_habitacion = numero_habitacion
        self.tipo = tipo
        self.disponible = True
    @property
    def numero_habitacion(self):
        return self._numero_habitacion
    @numero_habitacion.setter
    def numero_habitacion(self, valor):
        if valor <= 0:
            raise ValueError("El número debe ser mayor a cero")
        self._numero_habitacion = valor

    # Getter y setter de tipo
    @property
    def tipo(self):
        return self._tipo

    @tipo.setter
    def tipo(self, valor):
        if valor.lower() not in ["simple", "doble", "triple", "cuadruple"]:
            raise ValueError("Tipo de habitación no válido")
        self._tipo = valor.lower()


    # Getter y setter de disponible
    @property
    def disponible(self):
        return self._disponible

    @disponible.setter
    def disponible(self, valor):
        if not isinstance(valor, bool):
            raise ValueError("La disponibilidad debe ser True o False")
        self._disponible = valor

    def ocupar(self):
        if self._disponible == False:
            raise ValueError("La habitación ya está ocupada")
        self._disponible = False
        return f"La habitación está ocupada"

    def liberar(self):
        if self._disponible == True:
            raise ValueError("La habitación ya está libre")
        self._disponible = True
        return f"La habitación está libre"

def elegir_tipo():
    tipos = ["simple", "doble", "triple", "cuadruple"]

    for indice, tipo in enumerate(tipos, start=1):
        print(f"{indice}. {tipo}")

    opcion = int(input("Elegí el tipo de habitacion: ") or 0)

    if opcion < 1 or opcion > len(tipos):
        raise ValueError("Opción no válida")

    return tipos[opcion - 1]


def main():
    tipo_elegido = elegir_tipo()

#Pruebas
    habitacion1 = Habitacion(25,tipo_elegido)

    print(habitacion1.numero_habitacion)
    print(habitacion1.tipo)
    

    habitacion1.disponible = True
    print(habitacion1.disponible)
if __name__ == "__main__":
    main()
