# Hotel «Las Acacias»

Trabajo práctico de programación orientada a objetos. El programa simula la recepción de un hotel: arma habitaciones, registra huéspedes, confirma y cancela reservas, y muestra el tarifario.

El restaurante es el ejemplo de la cátedra. Este proyecto repite esa forma de trabajar con otro dominio.

## Equipo

| Rol | Nombre | Archivo | Qué aporta |
|---|---|---|---|
| Alumno 1 | Gonzalo Monge | `habitaciones.py` | La clase `Habitacion` |
| Alumno 2 | Facundo Miranda | `clientes.py` | `Cliente` y `ClienteVip` |
| Alumno 3 | Santiago Robledo | `reservas.py` | `Estadia` y `Reserva` |
| Alumno 4 | Mateo Lestarpe | `tarifas.py` | La clase `Tarifa` |
| Líder | Walter Sanchez | `main.py` | Junta los módulos y muestra la demo |

`main.py` es el único que importa a los demás y el único que arma la salida del programa completo. Cada módulo se puede probar solo.

## Qué muestra la demo

Al ejecutar `main.py` ocurre esto, en orden:

1. Muestra el tarifario: precio por noche y total a 3 noches de simple, doble, triple y cuádruple.
2. Crea cuatro habitaciones (101 simple, 102 doble, 201 triple y 202 cuádruple) y prueba ocupar y liberar la 202. La 202 no entra en ninguna reserva.
3. Registra a Ana Ruiz (cliente vip, 10 % de descuento), a Luis Paz y a Marta Solo. Ninguno entra con habitación: la asigna la reserva al confirmar.
4. Arma la reserva de Ana: 3 noches en la 101 y 2 en la 201. El total con descuento es **$ 292.500**. La confirma, esas habitaciones pasan a ocupadas y Ana queda con la 101.
5. Intenta agregar otra estadía a la reserva ya confirmada. El módulo lo rechaza, el error se muestra y el programa sigue.
6. Cancela la reserva de Ana. Las habitaciones vuelven a quedar libres y Ana queda sin habitación.
7. Arma la reserva de Luis: 2 noches en la 102, en estado pendiente, por **$ 140.000**.

Al final imprime una tabla de resumen. Cada sección queda en uno de estos estados:

- **funciona**: esa parte corrió bien.
- **fallo**: falló, y arriba está el error y el responsable.
- **te falta**: falta una función del líder.
- **sin probar**: no se llegó a ejecutar porque falló algo anterior.

Si una sección falla, la demo corta ahí. Las habitaciones usan las tarifas, y las reservas usan las habitaciones y los clientes.

## Cómo ejecutarlo

Hace falta Python 3.10 o superior y la librería `rich`. Desde la carpeta del proyecto:

```bash
python3 -m venv .venv
.venv/bin/pip install rich
.venv/bin/python main.py
```

Si ya existe el entorno virtual, alcanza con:

```bash
.venv/bin/python main.py
```

Con [uv](https://docs.astral.sh/uv/), que lee las dependencias de `pyproject.toml`:

```bash
uv run python main.py
```

## Probar un módulo solo

Cada archivo trae su propia prueba, al final, dentro de `if __name__ == "__main__":`. Esa prueba corre únicamente cuando se ejecuta ese archivo.

```bash
.venv/bin/python habitaciones.py   # pide el tipo de habitación por teclado
.venv/bin/python clientes.py
.venv/bin/python reservas.py       # usa habitaciones.py y clientes.py
.venv/bin/python tarifas.py
```

`reservas.py` necesita los otros dos módulos porque una reserva no existe sin un cliente y una habitación.
