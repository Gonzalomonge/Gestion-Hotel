#Módulo: Reservas del Hotel
# Clases del archivo: Estadia, Reserva
# Imports: Cliente y ClienteVip desde clientes.py, Habitacion desde habitaciones.py

from habitaciones import Habitacion 
from clientes import Cliente, ClienteVip
from tarifas import Tarifa

class Estadia: #Representa la reservación de una sola habitación antes de sacar el total reservado como un "detalle de compra"
    def __init__(self, habitacion: Habitacion, noches: int) -> None: 
        self.habitacion = habitacion
        self.noches = noches

    @property
    def noches(self) -> int:
        return self._noches 

    @noches.setter
    def noches(self, noches_new: int) -> None:
        if not isinstance(noches_new, int):
            raise TypeError (f"La cantdad de nohces debe ser un número entero")

        if noches_new <=0:
            raise ValueError(f"La cantidad de noches debe ser positiva y mayor a 0")

        self._noches = noches_new

    @property
    def habitacion(self) -> Habitacion:
        return self._habitacion

    @habitacion.setter
    def habitacion(self, habitacion_new: Habitacion) -> None:
        if not isinstance(habitacion_new, Habitacion):
            raise TypeError(f"El atributo ingresado debe pertenecer a la clase Habitacion")
        self._habitacion = habitacion_new

    def subtotal(self) -> int: 
        tarifa = self.habitacion.tarifa
        if not isinstance(tarifa, Tarifa):
            raise TypeError("La habitacion no tiene una tarifa")
        return tarifa.calcular_total(self.noches)

    def __str__(self) -> str:
        return f"{self.noches} noche/s en  la habitacion {self.habitacion.numero_habitacion}, {self.habitacion.tipo} "

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(habitacion= {self.habitacion.numero_habitacion}, noches= {self.noches})"

class Reserva: #una reserva completa, con un cliente, numero de reserva, y varias estadias, y un estado
    numero_reserva = 0
    estados = ("Pendiente", "Confirmada", "Cancelada")
    _habitaciones_tomadas = set()
    def __init__(self, cliente: Cliente, estado ='Pendiente') -> None: 
        
        self.cliente = cliente
        self._estado = estado
        self._estadias: list[Estadia] = [] 
        Reserva.numero_reserva += 1
        self.numero = Reserva.numero_reserva

    @property
    def cliente(self) -> Cliente:
        return self._cliente

    @cliente.setter
    def cliente(self, cliente_new: Cliente) -> None:
        if not isinstance(cliente_new, Cliente):
            raise TypeError(f"El atributo ingresado debe pertenecer a la clase Cliente")
        self._cliente = cliente_new

    @property
    def estado(self) -> str:
        return self._estado

    @property
    def estadias(self) -> tuple:
        return tuple(self._estadias)

    def agregar_estadia(self, habitacion: Habitacion, noches: int) -> None: 
        if self.estado != "Pendiente":
            raise RuntimeError(f"No se pueden agregar habitaciones a una reserva con este estado {self.estado}")

        if not habitacion.disponible:
            raise ValueError(f"La habitacion {habitacion.numero_habitacion} esta ocupada")

        if habitacion.numero_habitacion in Reserva._habitaciones_tomadas:
            raise ValueError(f"La habitacion {habitacion.numero_habitacion} ya esta en otra reserva")

        for i in self._estadias:
            if i.habitacion.numero_habitacion == habitacion.numero_habitacion:
                raise ValueError(f"La habitacion {habitacion.numero_habitacion} ya esta en la reserva")
        
        estadia = Estadia(habitacion, noches)
        self._estadias.append(estadia)
        Reserva._habitaciones_tomadas.add(habitacion.numero_habitacion)

    def total(self) -> float:
        bruto = sum(estadia.subtotal() for estadia in self._estadias)
        return round(bruto * (1 - self.cliente.descuento), 2)
    
    def habitaciones_totales(self) -> int: 
        return len(self._estadias)

    def cambiar_estado(self, estado_new: str) -> None: 
        if estado_new not in self.estados:
            raise ValueError (f"El estado debe ser alguno de los siguientes {self.estados}")
        
        elif estado_new == "Confirmada" and self.estado == "Confirmada":
            raise ValueError (f"No se puede confirmar una habitacion que ya esta cofirmada")

        elif estado_new == "Cancelada" and self.estado == "Cancelada":
            raise ValueError (f"No se puede cancelar una reserva que ya esta cancelada")
        
        elif estado_new == "Confirmada":
            for estadia in self._estadias:
                if not estadia.habitacion.disponible:
                    raise RuntimeError(f"No se puede confirmar: la habitacion {estadia.habitacion.numero_habitacion} porque ya esta ocupada")
            
            for estadia in self._estadias:
                estadia.habitacion.ocupar()
               
            if self._estadias:   
               self.cliente.habitacion = self._estadias[0].habitacion 
    
        elif estado_new == "Cancelada":
            if self.estado == "Confirmada":
                for estadia in self._estadias:
                    estadia.habitacion.liberar() 
            self.cliente.desasignar_habitacion()
            for estadia in self._estadias:
                Reserva._habitaciones_tomadas.discard(estadia.habitacion.numero_habitacion)
        self._estado = estado_new

    def __len__(self) -> int:
        return len(self._estadias)

    def __str__(self) -> str:
        return f"Reserva #{self.numero}, de {self.cliente.nombre} - {len(self._estadias)} habitación/es"

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(numero= {self.numero}, estado={self.estado})"





def main():
    pass

if __name__ == "__main__":
    main()












