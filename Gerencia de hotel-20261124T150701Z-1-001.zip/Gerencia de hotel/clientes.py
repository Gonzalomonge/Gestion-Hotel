
"""
Módulo — Clientes del hotel.

Autor: Facundo Miranda Sarandon

Contiene las clases Cliente y ClienteVip, que administran
los datos de los clientes del hotel, validan su información,
permiten asignar habitaciones y gestionar los descuentos
especiales para clientes VIP.
"""

from datetime import datetime


class Cliente:
    """Una persona que se hospeda en el hotel."""

    def __init__(self, nombre, email, habitacion=None):
        if not nombre.strip():
            raise ValueError("El nombre no puede estar vacío.")

        if "@" not in email:
            raise ValueError(f"{nombre}: email {email!r} no válido.")

        self.nombre = nombre
        self.email = email
        self.habitacion = habitacion
        self.registrado_en = datetime.now()

    @property
    def descuento(self):
        """Un cliente común no tiene descuento."""
        return 0.0

    @property
    def tiene_habitacion(self):
        """Indica si el cliente tiene una habitación asignada."""
        return self.habitacion is not None

    @property
    def numero_habitacion(self):
        """Devuelve el número de habitación o None si no tiene."""
        if self.habitacion is None:
            return None

        return self.habitacion.numero_habitacion

    def desasignar_habitacion(self):
        """Quita la habitación asignada al cliente."""
        habitacion = self.habitacion
        self.habitacion = None
        return habitacion

    def __str__(self):
        if self.tiene_habitacion:
            where = f", habitación {self.numero_habitacion}"
        else:
            where = ", sin habitación asignada"

        return f"{self.nombre}, {self.email}, {where}"

    def __repr__(self):
        return (
            f"Cliente(nombre={self.nombre!r}, "
            f"email={self.email!r})"
        )


class ClienteVip(Cliente):
    """Un cliente que tiene beneficios especiales."""

    def __init__(
        self, nombre, email, habitacion=None, descuento=0.10
    ):
        super().__init__(nombre, email, habitacion)

        if not 0 <= descuento < 1:
            raise ValueError(
                f"{nombre}: el descuento debe estar entre 0 y 1."
            )

        self._descuento = descuento

    @property
    def descuento(self):
        """Devuelve el descuento del cliente VIP."""
        return self._descuento

    def __str__(self):
        return f"{super().__str__()} - VIP {self._descuento:.0%}"

    def __repr__(self):
        return (
            f"ClienteVip(nombre={self.nombre!r}, "
            f"descuento={self._descuento!r})"
        )


if __name__ == "__main__":
    # Prueba del módulo solo, sin main.py:
    # uv run python clientes.py

    cliente = Cliente("Juan Pérez", "juan@ejemplo.com")

    cliente_vip = ClienteVip(
        "Ana Ruiz",
        "ana@ejemplo.com",
        descuento=0.10
    )

    print(cliente)
    print(cliente_vip)
    print(f"Descuento de {cliente_vip.nombre}: {cliente_vip.descuento:.0%}")
